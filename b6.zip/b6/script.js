(function () {
  const GROUPS = ["EM", "EI", "KM", "KI"];
  const BASE = 3;
  const table = document.getElementById("todoTable");
  const dateLabel = document.getElementById("dateLabel");
  const progress = document.getElementById("progress");
  const toast = document.getElementById("toast");

  let current = new Date();
  let activeRow = null;

  const pad = n => String(n).padStart(2, "0");
  const iso = d => d.getFullYear() + "-" + pad(d.getMonth() + 1) + "-" + pad(d.getDate());
  const fmt = d => pad(d.getDate()) + "." + pad(d.getMonth() + 1) + "." + d.getFullYear();
  const key = () => "vazifalar:" + iso(current);
  const rowsOf = g => Array.from(table.querySelectorAll('tr[data-group="' + g + '"]'));

  function showToast(msg) {
    toast.textContent = msg;
    toast.classList.add("show");
    clearTimeout(showToast.t);
    showToast.t = setTimeout(() => toast.classList.remove("show"), 1800);
  }

  function renumber(g) {
    rowsOf(g).forEach((tr, i) => { tr.querySelector(".num").textContent = (i + 1) + "."; });
  }
  function changeSpan(g, delta) {
    [g, g[0]].forEach(s => {
      const th = table.querySelector('th[data-span="' + s + '"]');
      th.rowSpan = th.rowSpan + delta;
    });
  }
  function addRow(g) {
    const rows = rowsOf(g);
    const tr = document.createElement("tr");
    tr.dataset.group = g;
    tr.innerHTML = '<td class="task"><span class="num"></span><input type="text" autocomplete="off"></td><td class="check"></td>';
    rows[rows.length - 1].after(tr);
    changeSpan(g, 1);
    renumber(g);
    return tr;
  }
  function removeLastRow(g) {
    const rows = rowsOf(g);
    if (rows.length <= BASE) return;
    const last = rows[rows.length - 1];
    if (last === activeRow) setActive(rows[0]);
    last.remove();
    changeSpan(g, -1);
  }

  function setActive(tr) {
    if (activeRow) activeRow.classList.remove("active");
    activeRow = tr;
    if (tr) tr.classList.add("active");
  }
  function updateProgress() {
    const all = table.querySelectorAll("tr[data-group]");
    const done = table.querySelectorAll("tr[data-group].done").length;
    progress.textContent = done + "/" + all.length;
  }

  function collect() {
    const out = {};
    GROUPS.forEach(g => {
      out[g] = rowsOf(g).map(tr => ({
        text: tr.querySelector("input").value,
        done: tr.classList.contains("done")
      }));
    });
    return out;
  }
  function save() {
    try { localStorage.setItem(key(), JSON.stringify(collect())); return true; }
    catch (e) { return false; }
  }
  function load() {
    let saved = null;
    try { saved = JSON.parse(localStorage.getItem(key())); } catch (e) {}
    GROUPS.forEach(g => {
      const items = (saved && saved[g]) || [];
      const target = Math.max(items.length, BASE);
      while (rowsOf(g).length < target) addRow(g);
      while (rowsOf(g).length > target) removeLastRow(g);
      rowsOf(g).forEach((tr, i) => {
        const it = items[i] || { text: "", done: false };
        tr.querySelector("input").value = it.text;
        tr.classList.toggle("done", !!it.done);
      });
    });
    dateLabel.textContent = fmt(current);
    setActive(rowsOf("EM")[0]);
    updateProgress();
  }

  table.addEventListener("focusin", e => {
    const tr = e.target.closest("tr[data-group]");
    if (tr) setActive(tr);
  });
  table.addEventListener("click", e => {
    const c = e.target.closest(".check");
    if (!c) return;
    const tr = c.closest("tr");
    tr.classList.toggle("done");
    setActive(tr);
    updateProgress();
  });

  document.getElementById("btnDone").addEventListener("click", () => {
    if (!activeRow) return;
    activeRow.classList.toggle("done");
    updateProgress();
  });
  document.getElementById("btnAdd").addEventListener("click", () => {
    const g = activeRow ? activeRow.dataset.group : "EM";
    const tr = addRow(g);
    setActive(tr);
    updateProgress();
    tr.querySelector("input").focus();
  });
  document.getElementById("btnConfirm").addEventListener("click", () => {
    showToast(save() ? "Saqlandi" : "Saqlab bo'lmadi");
  });
  function shift(d) {
    save();
    current = new Date(current.getFullYear(), current.getMonth(), current.getDate() + d);
    load();
  }
  document.getElementById("btnPrev").addEventListener("click", () => shift(-1));
  document.getElementById("btnNext").addEventListener("click", () => shift(1));

  load();
})();
