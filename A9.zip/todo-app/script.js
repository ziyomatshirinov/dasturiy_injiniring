// ===== ELEMENTLARNI OLISH =====
const taskForm = document.getElementById("taskForm");
const taskInput = document.getElementById("taskInput");
const todoList = document.getElementById("todoList");
const taskCounter = document.getElementById("taskCounter");
const progressBar = document.getElementById("progressBar");
const emptyMessage = document.getElementById("emptyMessage");
const filtersBox = document.getElementById("filters");
const clearCompletedBtn = document.getElementById("clearCompletedBtn");
const todoTemplate = document.getElementById("todoTemplate");

// ===== HOLAT (STATE) =====
let tasks = loadTasks();
let currentFilter = "all";
let justAddedId = null; // faqat yangi qo'shilgan vazifa animatsiya bilan chiqadi
const LEAVE_MS = 380; // CSS dagi o'chish animatsiyasi (0.4s) bilan mos

// ===== LOCALSTORAGE =====
function saveTasks() {
  localStorage.setItem("tasks", JSON.stringify(tasks));
}

function loadTasks() {
  try {
    return JSON.parse(localStorage.getItem("tasks")) || [];
  } catch {
    return [];
  }
}

// ===== ADD TASK =====
function addTask(text) {
  const task = {
    id: Date.now(),
    text: text.trim(),
    completed: false,
  };
  tasks.push(task);
  justAddedId = task.id;
  saveTasks();
  render();
}

// ===== DELETE TASK =====
function deleteTask(id, li) {
  if (li.classList.contains("leaving")) return;
  li.classList.add("leaving");
  setTimeout(() => {
    tasks = tasks.filter((t) => t.id !== id);
    saveTasks();
    render();
  }, LEAVE_MS);
}

// ===== COMPLETE TASK =====
function toggleTask(id, li) {
  const task = tasks.find((t) => t.id === id);
  if (!task) return;

  task.completed = !task.completed;
  saveTasks();

  if (currentFilter === "all") {
    // Ro'yxatni qayta chizmasdan, shu elementning o'zini yangilaymiz,
    // shunda belgi va chiziq animatsiyasi silliq ishlaydi.
    li.classList.toggle("completed", task.completed);
    updateCounter();
  } else {
    // Filtrda bo'lsa, vazifa ro'yxatdan chiqib ketishi kerak
    li.classList.add("leaving");
    setTimeout(() => render(), LEAVE_MS);
  }
}

// ===== EDIT TASK =====
function editTask(id, li) {
  const task = tasks.find((t) => t.id === id);
  const textEl = li.querySelector(".todo-text");

  const input = document.createElement("input");
  input.type = "text";
  input.className = "edit-input";
  input.value = task.text;
  input.maxLength = 100;

  textEl.replaceWith(input);
  input.focus();
  input.select();

  let finished = false;
  const finish = (save) => {
    if (finished) return;
    finished = true;
    const newText = input.value.trim();
    if (save && newText) {
      task.text = newText;
      saveTasks();
    }
    render();
  };

  input.addEventListener("keydown", (e) => {
    if (e.key === "Enter") finish(true);
    if (e.key === "Escape") finish(false);
  });
  input.addEventListener("blur", () => finish(true));
}

// ===== TASK COUNTER + PROGRESS =====
function updateCounter() {
  const total = tasks.length;
  const done = tasks.filter((t) => t.completed).length;
  const left = total - done;

  if (total === 0) {
    taskCounter.textContent = "Vazifalar yo'q";
  } else {
    taskCounter.textContent = `Jami: ${total} · Qolgan: ${left} · Bajarilgan: ${done}`;
  }

  progressBar.style.width = total ? `${(done / total) * 100}%` : "0%";
}

// ===== FILTER =====
function getFilteredTasks() {
  if (currentFilter === "active") return tasks.filter((t) => !t.completed);
  if (currentFilter === "completed") return tasks.filter((t) => t.completed);
  return tasks;
}

// ===== RENDER (ekranga chiqarish) =====
// animateAll = true bo'lsa, hamma vazifa birin-ketin chiroyli chiqadi
function render(animateAll = false) {
  todoList.innerHTML = "";
  const visible = getFilteredTasks();

  visible.forEach((task, index) => {
    const li = todoTemplate.content.firstElementChild.cloneNode(true);
    const checkbox = li.querySelector(".todo-check");
    const textEl = li.querySelector(".todo-text");
    const editBtn = li.querySelector(".edit-btn");
    const deleteBtn = li.querySelector(".delete-btn");

    li.dataset.id = task.id;
    textEl.textContent = task.text;
    checkbox.checked = task.completed;
    li.classList.toggle("completed", task.completed);

    if (animateAll || task.id === justAddedId) {
      li.classList.add("enter");
      if (animateAll) li.style.setProperty("--i", Math.min(index, 8));
    }

    checkbox.addEventListener("change", () => toggleTask(task.id, li));
    deleteBtn.addEventListener("click", () => deleteTask(task.id, li));
    editBtn.addEventListener("click", () => editTask(task.id, li));
    textEl.addEventListener("dblclick", () => editTask(task.id, li));

    todoList.appendChild(li);
  });

  justAddedId = null;
  emptyMessage.classList.toggle("show", visible.length === 0);
  updateCounter();
}

// ===== EVENTLAR =====
taskForm.addEventListener("submit", (e) => {
  e.preventDefault();
  const text = taskInput.value;
  if (!text.trim()) return;
  addTask(text);
  taskInput.value = "";
  taskInput.focus();
});

filtersBox.addEventListener("click", (e) => {
  const btn = e.target.closest(".btn-filter");
  if (!btn) return;
  currentFilter = btn.dataset.filter;
  filtersBox.querySelectorAll(".btn-filter").forEach((b) => b.classList.remove("active"));
  btn.classList.add("active");
  render(true);
});

clearCompletedBtn.addEventListener("click", () => {
  const doneItems = todoList.querySelectorAll(".todo-item.completed");
  doneItems.forEach((li) => li.classList.add("leaving"));

  setTimeout(() => {
    tasks = tasks.filter((t) => !t.completed);
    saveTasks();
    render();
  }, doneItems.length ? LEAVE_MS : 0);
});

// ===== BOSHLASH =====
render(true);
