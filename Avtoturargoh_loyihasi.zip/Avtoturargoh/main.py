import tkinter as tk
from tkinter import ttk, messagebox
import sqlite3
from datetime import datetime
import math

DB_NAME = "parking.db"
TOTAL_SLOTS = 30
PRICE_PER_HOUR = 5000

BG = "#F1F5F9"
NAVY = "#172B4D"
BLUE = "#2563EB"
GREEN = "#16A34A"
RED = "#DC2626"
ORANGE = "#EA580C"
WHITE = "#FFFFFF"
TEXT = "#1E293B"
MUTED = "#64748B"


class ParkingApp:
    def __init__(self, root):
        self.root = root
        self.root.title("SMART PARKING | Avtoturargoh")
        self.root.geometry("1250x820")
        self.root.minsize(1050, 700)
        self.root.configure(bg=BG)

        self.conn = sqlite3.connect(DB_NAME)
        self.conn.row_factory = sqlite3.Row
        self.create_database()
        self.setup_style()
        self.create_layout()
        self.show_dashboard()
        self.root.protocol("WM_DELETE_WINDOW", self.close_app)

    def create_database(self):
        self.conn.execute("""
            CREATE TABLE IF NOT EXISTS vehicles (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                slot_no INTEGER NOT NULL,
                plate TEXT NOT NULL,
                owner TEXT NOT NULL,
                phone TEXT,
                entry_time TEXT NOT NULL,
                exit_time TEXT,
                duration_minutes INTEGER DEFAULT 0,
                fee INTEGER DEFAULT 0,
                status TEXT DEFAULT 'IN'
            )
        """)
        self.conn.execute("""
            CREATE UNIQUE INDEX IF NOT EXISTS unique_active_slot
            ON vehicles(slot_no) WHERE status = 'IN'
        """)
        self.conn.execute("""
            CREATE UNIQUE INDEX IF NOT EXISTS unique_active_plate
            ON vehicles(plate) WHERE status = 'IN'
        """)
        self.conn.commit()

    def setup_style(self):
        style = ttk.Style()
        style.theme_use("clam")
        style.configure("Treeview", background=WHITE, foreground=TEXT,
                        rowheight=35, fieldbackground=WHITE,
                        font=("Arial", 10))
        style.configure("Treeview.Heading", background=NAVY,
                        foreground=WHITE, font=("Arial", 10, "bold"),
                        padding=10)
        style.map("Treeview",
                  background=[("selected", "#DBEAFE")],
                  foreground=[("selected", NAVY)])

    def create_layout(self):
        self.sidebar = tk.Frame(self.root, bg=NAVY, width=220)
        self.sidebar.pack(side="left", fill="y")
        self.sidebar.pack_propagate(False)

        tk.Label(self.sidebar, text="🚘 SMART\n     PARKING",
                 bg=NAVY, fg=WHITE, font=("Arial", 19, "bold"),
                 justify="left").pack(pady=(35, 45))

        self.nav_button("⌂  Bosh sahifa", self.show_dashboard)
        self.nav_button("▤  Avtomobillar tarixi", self.show_history)
        self.nav_button("＋  Avtomobil kiritish", self.add_vehicle_dialog)

        tk.Frame(self.sidebar, bg="#334766", height=1).pack(
            fill="x", padx=20, pady=25)
        tk.Label(self.sidebar, text="TURARGOH SIG'IMI",
                 bg=NAVY, fg="#AFC2DC",
                 font=("Arial", 9, "bold")).pack(pady=5)
        tk.Label(self.sidebar, text="30 TA JOY",
                 bg=NAVY, fg=WHITE,
                 font=("Arial", 17, "bold")).pack(pady=5)
        tk.Label(self.sidebar, text="SMART PARKING v1.0",
                 bg=NAVY, fg="#AFC2DC",
                 font=("Arial", 9)).pack(side="bottom", pady=20)

        self.content = tk.Frame(self.root, bg=BG)
        self.content.pack(side="right", fill="both", expand=True)

    def nav_button(self, text, command):
        tk.Button(self.sidebar, text=text, command=command,
                  bg=NAVY, fg=WHITE, activebackground="#334766",
                  activeforeground=WHITE, font=("Arial", 11, "bold"),
                  anchor="w", bd=0, padx=25, pady=15,
                  cursor="hand2").pack(fill="x", padx=8, pady=3)

    def clear_content(self):
        for widget in self.content.winfo_children():
            widget.destroy()

    def get_active_vehicles(self):
        return self.conn.execute(
            "SELECT * FROM vehicles WHERE status='IN' ORDER BY slot_no"
        ).fetchall()

    def get_vehicle_by_slot(self, slot_no):
        return self.conn.execute(
            "SELECT * FROM vehicles WHERE slot_no=? AND status='IN'",
            (slot_no,)
        ).fetchone()

    def get_free_slots(self):
        occupied = {v["slot_no"] for v in self.get_active_vehicles()}
        return [i for i in range(1, TOTAL_SLOTS + 1) if i not in occupied]

    def show_dashboard(self):
        self.clear_content()
        header = tk.Frame(self.content, bg=BG)
        header.pack(fill="x", padx=30, pady=(25, 15))
        tk.Label(header, text="Avtoturargoh boshqaruvi", bg=BG,
                 fg=NAVY, font=("Arial", 23, "bold")).pack(side="left")
        tk.Button(header, text="⟳ Yangilash",
                  command=self.show_dashboard, bg=BLUE, fg=WHITE,
                  font=("Arial", 10, "bold"), bd=0, padx=16, pady=10,
                  cursor="hand2").pack(side="right")

        tk.Label(self.content,
                 text=datetime.now().strftime("%d.%m.%Y  |  %H:%M:%S"),
                 bg=BG, fg=MUTED, font=("Arial", 10)).pack(
                     anchor="w", padx=32)

        active = self.get_active_vehicles()
        occupied = len(active)
        free = TOTAL_SLOTS - occupied
        today_income = self.conn.execute("""
            SELECT COALESCE(SUM(fee), 0) FROM vehicles
            WHERE status='OUT' AND date(exit_time)=date('now','localtime')
        """).fetchone()[0]
        total_income = self.conn.execute("""
            SELECT COALESCE(SUM(fee), 0) FROM vehicles WHERE status='OUT'
        """).fetchone()[0]

        stats = tk.Frame(self.content, bg=BG)
        stats.pack(fill="x", padx=25, pady=22)
        self.stat_card(stats, "Jami joylar", TOTAL_SLOTS,
                       "Avtoturargoh sig'imi", NAVY)
        self.stat_card(stats, "Band joylar", occupied,
                       "Avtomobillar soni", ORANGE)
        self.stat_card(stats, "Bo'sh joylar", free,
                       "Mavjud joylar", GREEN)
        self.stat_card(stats, "Bugungi daromad", f"{today_income:,} so'm",
                       "Bugungi tushum", BLUE)

        tk.Label(self.content, text=f"Umumiy daromad: {total_income:,} so'm",
                 bg=BG, fg=MUTED, font=("Arial", 10, "bold")).pack(
                     anchor="e", padx=35)

        section = tk.Frame(self.content, bg=BG)
        section.pack(fill="x", padx=30, pady=(15, 5))
        tk.Label(section, text="AVTOTURARGOH XARITASI", bg=BG,
                 fg=NAVY, font=("Arial", 15, "bold")).pack(side="left")
        tk.Label(section, text="Joyni tanlash uchun ustiga bosing",
                 bg=BG, fg=MUTED, font=("Arial", 9)).pack(side="right")

        parking_frame = tk.Frame(self.content, bg=WHITE, padx=20, pady=18)
        parking_frame.pack(fill="both", expand=True, padx=30, pady=10)
        active_by_slot = {v["slot_no"]: v for v in active}

        for i in range(1, TOTAL_SLOTS + 1):
            row, col = (i - 1) // 6, (i - 1) % 6
            vehicle = active_by_slot.get(i)
            if vehicle:
                color, foreground = "#FEE2E2", RED
                label = f"🚗 JOY {i}\n{vehicle['plate']}\nBAND"
            else:
                color, foreground = "#DCFCE7", GREEN
                label = f"🅿 JOY {i}\nBO'SH\nMAVJUD"
            tk.Button(
                parking_frame, text=label, bg=color, fg=foreground,
                activebackground=color, activeforeground=foreground,
                font=("Arial", 9, "bold"), bd=0, relief="flat",
                cursor="hand2", height=4,
                command=lambda n=i: self.slot_clicked(n)
            ).grid(row=row, column=col, padx=8, pady=8, sticky="nsew")

        for col in range(6):
            parking_frame.grid_columnconfigure(col, weight=1)

        footer = tk.Frame(self.content, bg=BG)
        footer.pack(fill="x", padx=30, pady=(5, 18))
        tk.Label(footer, text="🟢 Bo'sh joy       🔴 Band joy",
                 bg=BG, fg=TEXT, font=("Arial", 10, "bold")).pack(side="left")
        tk.Label(footer, text=f"1 soat narxi: {PRICE_PER_HOUR:,} so'm",
                 bg=BG, fg=BLUE, font=("Arial", 10, "bold")).pack(side="right")

    def stat_card(self, parent, title, value, subtitle, color):
        card = tk.Frame(parent, bg=WHITE, highlightbackground="#E2E8F0",
                        highlightthickness=1, padx=15, pady=15)
        card.pack(side="left", fill="both", expand=True, padx=5)
        tk.Label(card, text=title, bg=WHITE, fg=MUTED,
                 font=("Arial", 10, "bold")).pack(anchor="w")
        tk.Label(card, text=str(value), bg=WHITE, fg=color,
                 font=("Arial", 20, "bold")).pack(anchor="w", pady=7)
        tk.Label(card, text=subtitle, bg=WHITE, fg=MUTED,
                 font=("Arial", 8)).pack(anchor="w")

    def slot_clicked(self, slot_no):
        vehicle = self.get_vehicle_by_slot(slot_no)
        if vehicle:
            self.show_vehicle_details(vehicle)
        else:
            self.add_vehicle_dialog(slot_no)

    def add_vehicle_dialog(self, selected_slot=None):
        free_slots = self.get_free_slots()
        if not free_slots:
            messagebox.showwarning(
                "Avtoturargoh to'la",
                "Barcha 30 ta joy band! Yangi avtomobil kiritish uchun joy bo'shating."
            )
            return

        win = tk.Toplevel(self.root)
        win.title("Avtomobilni ro'yxatga olish")
        win.geometry("460x520")
        win.configure(bg=BG)
        win.resizable(False, False)
        win.transient(self.root)
        win.grab_set()

        tk.Label(win, text="🚘 YANGI AVTOMOBIL", bg=BG, fg=NAVY,
                 font=("Arial", 19, "bold")).pack(pady=(25, 5))
        tk.Label(win, text="Avtomobil ma'lumotlarini kiriting",
                 bg=BG, fg=MUTED, font=("Arial", 10)).pack(pady=(0, 20))

        form = tk.Frame(win, bg=WHITE, padx=25, pady=20)
        form.pack(fill="both", padx=25, pady=5)

        def create_field(label, placeholder=""):
            tk.Label(form, text=label, bg=WHITE, fg=TEXT,
                     font=("Arial", 10, "bold")).pack(anchor="w", pady=(8, 5))
            entry = tk.Entry(form, font=("Arial", 12), bd=1,
                             relief="solid", highlightthickness=1,
                             highlightbackground="#CBD5E1")
            entry.pack(fill="x", ipady=7)
            if placeholder:
                entry.insert(0, placeholder)
            return entry

        plate_entry = create_field("Davlat raqami", "Masalan: 01A123BC")
        owner_entry = create_field("Avtomobil egasining ismi")
        phone_entry = create_field("Telefon raqami (ixtiyoriy)")

        tk.Label(form, text="Avtoturargoh joyi", bg=WHITE, fg=TEXT,
                 font=("Arial", 10, "bold")).pack(anchor="w", pady=(12, 5))
        default_slot = selected_slot if selected_slot in free_slots else free_slots[0]
        slot_var = tk.StringVar(value=str(default_slot))
        ttk.Combobox(form, textvariable=slot_var, values=free_slots,
                     state="readonly", font=("Arial", 11)).pack(
                         fill="x", ipady=5)

        def save_vehicle():
            plate = plate_entry.get().strip().upper()
            owner = owner_entry.get().strip()
            phone = phone_entry.get().strip()
            if plate == "MASALAN: 01A123BC":
                plate = ""
            try:
                slot = int(slot_var.get())
            except ValueError:
                slot = -1

            if not plate:
                messagebox.showerror("Xatolik", "Davlat raqamini kiriting!", parent=win)
                return
            if not owner:
                messagebox.showerror("Xatolik", "Avtomobil egasining ismini kiriting!", parent=win)
                return
            if slot not in self.get_free_slots():
                messagebox.showerror("Xatolik", "Tanlangan joy allaqachon band!", parent=win)
                return

            entry_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            try:
                self.conn.execute("""
                    INSERT INTO vehicles
                    (slot_no, plate, owner, phone, entry_time, status)
                    VALUES (?, ?, ?, ?, ?, 'IN')
                """, (slot, plate, owner, phone, entry_time))
                self.conn.commit()
                messagebox.showinfo(
                    "Muvaffaqiyatli",
                    f"Avtomobil ro'yxatga olindi!\n\nRaqami: {plate}\n"
                    f"Joy: {slot}\nKirish: {entry_time}",
                    parent=win
                )
                win.destroy()
                self.show_dashboard()
            except sqlite3.IntegrityError:
                self.conn.rollback()
                messagebox.showerror(
                    "Xatolik",
                    "Bu avtomobil raqami allaqachon turargohda yoki joy band!",
                    parent=win
                )

        tk.Button(win, text="✓  AVTOMOBILNI KIRITISH",
                  command=save_vehicle, bg=GREEN, fg=WHITE,
                  font=("Arial", 11, "bold"), bd=0, pady=13,
                  cursor="hand2").pack(fill="x", padx=25, pady=15)

    def show_vehicle_details(self, vehicle):
        win = tk.Toplevel(self.root)
        win.title("Avtomobil ma'lumotlari")
        win.geometry("430x410")
        win.configure(bg=BG)
        win.resizable(False, False)
        win.transient(self.root)
        win.grab_set()

        tk.Label(win, text="🚗 AVTOMOBIL MA'LUMOTI", bg=BG, fg=NAVY,
                 font=("Arial", 17, "bold")).pack(pady=25)
        details = [
            ("Davlat raqami", vehicle["plate"]),
            ("Egasi", vehicle["owner"]),
            ("Telefon", vehicle["phone"] or "-"),
            ("Joy raqami", vehicle["slot_no"]),
            ("Kirish vaqti", vehicle["entry_time"])
        ]
        card = tk.Frame(win, bg=WHITE, padx=25, pady=15)
        card.pack(fill="x", padx=25)
        for key, value in details:
            row = tk.Frame(card, bg=WHITE)
            row.pack(fill="x", pady=7)
            tk.Label(row, text=key + ":", bg=WHITE, fg=MUTED,
                     font=("Arial", 10)).pack(side="left")
            tk.Label(row, text=str(value), bg=WHITE, fg=NAVY,
                     font=("Arial", 10, "bold")).pack(side="right")

        tk.Button(win, text="AVTOMOBILNI CHIQARISH",
                  command=lambda: self.exit_vehicle(vehicle["id"], win),
                  bg=RED, fg=WHITE, font=("Arial", 11, "bold"),
                  bd=0, pady=13, cursor="hand2").pack(
                      fill="x", padx=25, pady=20)

    def exit_vehicle(self, vehicle_id, detail_window=None):
        vehicle = self.conn.execute(
            "SELECT * FROM vehicles WHERE id=? AND status='IN'",
            (vehicle_id,)
        ).fetchone()
        if not vehicle:
            messagebox.showerror("Xatolik", "Avtomobil topilmadi!")
            if detail_window:
                detail_window.destroy()
            return

        now = datetime.now()
        entry = datetime.strptime(vehicle["entry_time"], "%Y-%m-%d %H:%M:%S")
        seconds = max(0, (now - entry).total_seconds())
        minutes = math.ceil(seconds / 60)
        hours = max(1, math.ceil(seconds / 3600))
        fee = hours * PRICE_PER_HOUR

        confirm = messagebox.askyesno(
            "Avtomobilni chiqarish",
            f"Avtomobil: {vehicle['plate']}\nJoy: {vehicle['slot_no']}\n"
            f"Kirish vaqti: {vehicle['entry_time']}\n"
            f"Chiqish vaqti: {now.strftime('%Y-%m-%d %H:%M:%S')}\n"
            f"Turish vaqti: {minutes} daqiqa\n"
            f"Hisoblangan vaqt: {hours} soat\n\n"
            f"TO'LOV: {fee:,} so'm\n\nAvtomobil chiqarilsinmi?"
        )
        if not confirm:
            return

        try:
            self.conn.execute("""
                UPDATE vehicles
                SET status='OUT', exit_time=?, duration_minutes=?, fee=?
                WHERE id=? AND status='IN'
            """, (now.strftime("%Y-%m-%d %H:%M:%S"),
                  minutes, fee, vehicle_id))
            self.conn.commit()
            if detail_window:
                detail_window.destroy()
            messagebox.showinfo(
                "To'lov muvaffaqiyatli",
                f"Avtomobil chiqarildi!\n\nRaqami: {vehicle['plate']}\n"
                f"Turish vaqti: {minutes} daqiqa\n"
                f"To'lov: {fee:,} so'm\n\nJoy {vehicle['slot_no']} bo'shatildi."
            )
            self.show_dashboard()
        except sqlite3.Error as error:
            self.conn.rollback()
            messagebox.showerror("Baza xatoligi", str(error))

    def show_history(self):
        self.clear_content()
        header = tk.Frame(self.content, bg=BG)
        header.pack(fill="x", padx=30, pady=25)
        tk.Label(header, text="Avtomobillar tarixi", bg=BG, fg=NAVY,
                 font=("Arial", 23, "bold")).pack(side="left")
        tk.Button(header, text="⟳ Yangilash", command=self.show_history,
                  bg=BLUE, fg=WHITE, font=("Arial", 10, "bold"),
                  bd=0, padx=15, pady=10, cursor="hand2").pack(side="right")

        search_frame = tk.Frame(self.content, bg=BG)
        search_frame.pack(fill="x", padx=30, pady=10)
        tk.Label(search_frame, text="Davlat raqami bo'yicha qidirish:",
                 bg=BG, fg=TEXT, font=("Arial", 10, "bold")).pack(
                     side="left", padx=(0, 10))
        search_entry = tk.Entry(search_frame, font=("Arial", 11), width=28)
        search_entry.pack(side="left", ipady=7)

        table_frame = tk.Frame(self.content, bg=WHITE)
        table_frame.pack(fill="both", expand=True, padx=30, pady=15)
        columns = ("id", "slot", "plate", "owner", "entry",
                   "exit", "duration", "fee", "status")
        tree = ttk.Treeview(table_frame, columns=columns, show="headings")
        headings = {
            "id": "ID", "slot": "Joy", "plate": "Davlat raqami",
            "owner": "Avtomobil egasi", "entry": "Kirish vaqti",
            "exit": "Chiqish vaqti", "duration": "Daqiqa",
            "fee": "To'lov", "status": "Holati"
        }
        widths = {
            "id": 40, "slot": 45, "plate": 105, "owner": 120,
            "entry": 145, "exit": 145, "duration": 65,
            "fee": 100, "status": 80
        }
        for col in columns:
            tree.heading(col, text=headings[col])
            tree.column(col, width=widths[col], anchor="center")
        scrollbar = ttk.Scrollbar(table_frame, orient="vertical", command=tree.yview)
        tree.configure(yscrollcommand=scrollbar.set)
        tree.pack(side="left", fill="both", expand=True, padx=8, pady=8)
        scrollbar.pack(side="right", fill="y", pady=8)
        tree.tag_configure("IN", foreground=GREEN)
        tree.tag_configure("OUT", foreground=RED)

        def load_history(*args):
            tree.delete(*tree.get_children())
            keyword = search_entry.get().strip().upper()
            rows = self.conn.execute("""
                SELECT * FROM vehicles WHERE UPPER(plate) LIKE ?
                ORDER BY id DESC
            """, (f"%{keyword}%",)).fetchall()
            for v in rows:
                status = "BAND" if v["status"] == "IN" else "CHIQDI"
                tree.insert("", "end", values=(
                    v["id"], v["slot_no"], v["plate"], v["owner"],
                    v["entry_time"], v["exit_time"] or "-",
                    v["duration_minutes"], f"{v['fee']:,}", status
                ), tags=(v["status"],))

        search_entry.bind("<KeyRelease>", load_history)
        load_history()

        def history_exit():
            selected = tree.selection()
            if not selected:
                messagebox.showwarning("Diqqat", "Avval avtomobilni tanlang!")
                return
            values = tree.item(selected[0], "values")
            vehicle_id = int(values[0])
            vehicle = self.conn.execute(
                "SELECT * FROM vehicles WHERE id=? AND status='IN'",
                (vehicle_id,)
            ).fetchone()
            if vehicle:
                self.exit_vehicle(vehicle_id)
            else:
                messagebox.showinfo("Ma'lumot", "Bu avtomobil avval chiqarilgan.")
            self.show_history()

        bottom = tk.Frame(self.content, bg=BG)
        bottom.pack(fill="x", padx=30, pady=(0, 20))
        tk.Button(bottom, text="Tanlangan avtomobilni chiqarish",
                  command=history_exit, bg=RED, fg=WHITE,
                  font=("Arial", 10, "bold"), bd=0, padx=15,
                  pady=10, cursor="hand2").pack(side="left")
        total = self.conn.execute(
            "SELECT COALESCE(SUM(fee), 0) FROM vehicles WHERE status='OUT'"
        ).fetchone()[0]
        tk.Label(bottom, text=f"Jami tushum: {total:,} so'm",
                 bg=BG, fg=GREEN, font=("Arial", 12, "bold")).pack(side="right")

    def close_app(self):
        self.conn.close()
        self.root.destroy()


if __name__ == "__main__":
    root = tk.Tk()
    app = ParkingApp(root)
    root.mainloop()
