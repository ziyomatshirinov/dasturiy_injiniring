SMART PARKING — Avtoturargoh boshqaruv dasturi

Talablar:
- Python 3.9 yoki undan yangi versiya
- Tkinter (odatda Python bilan birga o'rnatiladi)
- SQLite (Python tarkibida mavjud)

Ishga tushirish:
1. ZIP faylni oching.
2. Avtoturargoh papkasiga kiring.
3. Terminal/CMD ochib quyidagini bajaring:
   python main.py
   yoki Windows'da:
   py main.py

Dastur birinchi marta ishga tushganda parking.db bazasi avtomatik yaratiladi.
Muhim: parking.db faylini o'chirmang — u avtomobillar tarixi va to'lovlarni saqlaydi.

Sozlamalar:
main.py faylining yuqorisidagi:
TOTAL_SLOTS = 30
PRICE_PER_HOUR = 5000
qiymatlarini o'zgartirib, sig'im va soatlik tarifni moslashingiz mumkin.

Eslatma:
To'lov hisobida har boshlangan soat uchun 5 000 so'm olinadi.
Bu o'quv loyihasi bo'lib, real to'lov yoki shlagbaum qurilmasiga ulanmagan.
