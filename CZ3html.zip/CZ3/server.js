// CZ3 Chat serveri: index.html ni beradi va Claude API ga xavfsiz murojaat qiladi.
// Ishga tushirish:  node server.js   (Node.js 18 yoki yangi kerak)
const http = require("http");
const fs = require("fs");
const path = require("path");

// .env faylidan o'qish (ANTHROPIC_API_KEY=sk-ant-...)
try {
  fs.readFileSync(path.join(__dirname, ".env"), "utf8").split(/\r?\n/).forEach(function (line) {
    const m = line.match(/^\s*([A-Z_]+)\s*=\s*(.*?)\s*$/);
    if (m && !process.env[m[1]]) process.env[m[1]] = m[2].replace(/^["']|["']$/g, "");
  });
} catch (e) {}

const KEY = process.env.ANTHROPIC_API_KEY || "";
const MODEL = process.env.CLAUDE_MODEL || "claude-sonnet-5-5";
const PORT = process.env.PORT || 3000;

function json(res, code, obj) {
  res.writeHead(code, { "Content-Type": "application/json; charset=utf-8" });
  res.end(JSON.stringify(obj));
}

function cleanMessages(arr) {
  const out = [];
  (Array.isArray(arr) ? arr : []).slice(-20).forEach(function (m) {
    if (!m || (m.role !== "user" && m.role !== "assistant") || typeof m.content !== "string") return;
    const content = m.content.slice(0, 2000).trim();
    if (!content) return;
    if (out.length && out[out.length - 1].role === m.role) out[out.length - 1].content += "\n" + content;
    else out.push({ role: m.role, content: content });
  });
  while (out.length && out[0].role !== "user") out.shift();
  return out;
}

async function chat(req, res) {
  if (!KEY) return json(res, 503, { error: "API kalit sozlanmagan (.env faylini tekshiring)." });
  let body = "";
  req.on("data", function (c) { body += c; if (body.length > 200000) req.destroy(); });
  req.on("end", async function () {
    try {
      const data = JSON.parse(body || "{}");
      const messages = cleanMessages(data.messages);
      if (!messages.length || messages[messages.length - 1].role !== "user")
        return json(res, 400, { error: "Xabar topilmadi." });
      const persona = String(data.persona || "do'st").replace(/[^\w\- ]/g, "").slice(0, 30) || "do'st";
      const system =
        "Sen chat ilovasidagi \"" + persona + "\" nomli suhbatdoshsan. " +
        "Foydalanuvchi qaysi tilda yozsa, shu tilda javob ber (asosan o'zbek tili, lotin yozuvida). " +
        "Samimiy, tabiiy va aniq javob ber. Oddiy chat xabari kabi qisqa yoz (1-4 gap), " +
        "faqat foydalanuvchi batafsil so'rasa uzunroq yoz. Salomga \"Vaaleykum assalom\" deb javob ber. " +
        "Har qanday savolga (dasturlash, matematika, maslahat, umumiy bilimlar) yordam ber.";
      const r = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: { "content-type": "application/json", "x-api-key": KEY, "anthropic-version": "2023-06-01" },
        body: JSON.stringify({ model: MODEL, max_tokens: 600, system: system, messages: messages })
      });
      const d = await r.json();
      if (!r.ok) {
        console.error("Claude API xatosi:", r.status, JSON.stringify(d));
        return json(res, 502, { error: (d.error && d.error.message) || "Claude API xatosi" });
      }
      const text = (d.content || []).filter(function (b) { return b.type === "text"; })
        .map(function (b) { return b.text; }).join("\n").trim();
      json(res, 200, { reply: text || "..." });
    } catch (e) {
      console.error(e);
      json(res, 500, { error: "Server xatosi" });
    }
  });
}

http.createServer(function (req, res) {
  const url = req.url.split("?")[0];
  if (req.method === "GET" && url === "/api/status") return json(res, 200, { ai: !!KEY, model: MODEL });
  if (req.method === "POST" && url === "/api/chat") return chat(req, res);
  if (req.method === "GET") {
    const rel = url === "/" ? "index.html" : decodeURIComponent(url).replace(/^\/+/, "");
    const allowed = rel === "index.html" || /^(css|js)\/[\w.\-]+$/.test(rel);
    if (allowed) {
      const types = { ".html": "text/html", ".css": "text/css", ".js": "application/javascript" };
      return fs.readFile(path.join(__dirname, rel), function (err, buf) {
        if (err) { res.writeHead(404); return res.end("Topilmadi"); }
        res.writeHead(200, { "Content-Type": (types[path.extname(rel)] || "text/plain") + "; charset=utf-8" });
        res.end(buf);
      });
    }
  }
  res.writeHead(404); res.end("Topilmadi");
}).listen(PORT, function () {
  console.log("CZ3 Chat ishga tushdi: http://localhost:" + PORT);
  console.log(KEY ? "Claude AI yoqilgan (" + MODEL + ")" : "DIQQAT: ANTHROPIC_API_KEY yo'q - oddiy javoblar rejimi.");
});
