CZ3 Chat - Claude AI bilan

ODDIY REJIM (kalit kerak emas)
  index.html ni ikki marta bosing. Tayyor javoblar bilan ishlaydi.

CLAUDE AI REJIMI (istalgan savolga javob)
  1) Node.js o'rnating (nodejs.org, LTS versiya).
  2) https://console.anthropic.com saytida API kalit oling.
  3) ".env.example" faylidan nusxa oling, nomini ".env" qiling va ichiga kalitni yozing:
       ANTHROPIC_API_KEY=sk-ant-.....
  4) Windows: start.bat ni ikki marta bosing.
     Boshqa tizim: terminalda  node server.js  deb yozing, keyin brauzerda http://localhost:3000
  5) Chatda chap yuqorida "Claude AI yoqilgan" yozuvi chiqadi.

MUHIM
  - .env faylini hech kimga bermang va GitHub'ga yuklamang (.gitignore da yozilgan).
  - GitHub Pages serverni ishlata olmaydi, u yerda faqat oddiy rejim ishlaydi.
    AI uchun serverni Render, Railway yoki o'z kompyuteringizda ishga tushiring.
