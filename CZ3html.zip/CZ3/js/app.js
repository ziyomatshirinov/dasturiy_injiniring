(function () {
  var $ = function (id) { return document.getElementById(id); };

  /* ---- Saqlash (localStorage, ishlamasa xotirada) ---- */
  var mem = {};
  function load(key, def) {
    try { var v = localStorage.getItem(key); return v ? JSON.parse(v) : def; }
    catch (e) { return mem[key] !== undefined ? mem[key] : def; }
  }
  function save(key, val) {
    mem[key] = val;
    try { localStorage.setItem(key, JSON.stringify(val)); } catch (e) {}
  }

  var DEMO = ["aziz", "malika", "sardor"]; // doim ro'yxatda turadigan loginlar
  var me = null, peer = null;

  function show(name) {
    ["vLogin", "vRegister", "vChat"].forEach(function (v) { $(v).classList.add("hidden"); });
    $(name).classList.remove("hidden");
  }
  function say(id, text, ok) { var el = $(id); el.textContent = text; el.className = "msg" + (ok ? " ok" : ""); }
  function users() { return load("cz3_users", []); }

  /* ---- Kirish ---- */
  function doLogin() {
    var login = $("lLogin").value.trim(), parol = $("lParol").value;
    if (!login || !parol) return say("lMsg", "Login va parolni kiriting.");
    var u = users().filter(function (x) { return x.login.toLowerCase() === login.toLowerCase(); })[0];
    if (!u) return say("lMsg", "Bunday login yo'q. Avval \"Ro'yxatdan o'tish\" tugmasini bosing.");
    if (u.parol !== parol) return say("lMsg", "Parol noto'g'ri.");
    me = u; save("cz3_session", u.login); openChat();
  }

  /* ---- Ro'yxatdan o'tish ---- */
  function doRegister() {
    var login = $("rLogin").value.trim(), fam = $("rFam").value.trim(), ism = $("rIsm").value.trim(),
        p1 = $("rParol").value, p2 = $("rParol2").value;
    if (!login || !fam || !ism || !p1 || !p2) return say("rMsg", "Hamma maydonlarni to'ldiring.");
    if (/\s/.test(login)) return say("rMsg", "Loginda bo'sh joy bo'lmasin.");
    if (p1.length < 4) return say("rMsg", "Parol kamida 4 ta belgi bo'lsin.");
    if (p1 !== p2) return say("rMsg", "Parollar bir xil emas.");
    var list = users();
    var taken = list.some(function (x) { return x.login.toLowerCase() === login.toLowerCase(); }) ||
                DEMO.indexOf(login.toLowerCase()) !== -1;
    if (taken) return say("rMsg", "Bu login band. Boshqa login tanlang.");
    list.push({ login: login, familiya: fam, ism: ism, parol: p1 });
    save("cz3_users", list);
    say("rMsg", "Ro'yxatdan o'tdingiz! Kirish oynasiga o'tilmoqda...", true);
    setTimeout(function () {
      $("lLogin").value = login; $("lParol").value = "";
      say("lMsg", "Endi parolingiz bilan kiring.", true);
      show("vLogin"); $("lParol").focus();
    }, 900);
  }

  /* ---- Chat ---- */
  function contacts() {
    var reg = users().map(function (u) { return u.login; }).filter(function (l) { return l !== me.login; });
    return reg.concat(DEMO.filter(function (d) { return reg.indexOf(d) === -1; }));
  }
  function pick(a) { return a[Math.floor(Math.random() * a.length)]; }
  function getReply(text, who) {
    var t = text.toLowerCase().replace(/[\u02bb\u02bc\u2019\u2018`\u00b4]/g, "'");
    var has = function (re) { return re.test(t); };
    var now = new Date();
    if (has(/salom|assalom|hayrli|xayrli/)) return "Vaaleykum assalom";
    if (has(/qalaysan|qalaysiz|qandaysan|qandaysiz|ahvol|holing|holingiz|yaxshimisan|yaxshimisiz|nima gap|nima yangilik/))
      return pick(["Yaxshi, rahmat! O'zingiz qalaysiz?", "Alhamdulillah, yaxshi. Sizda nima yangilik?"]);
    if (has(/ismi|isming|ismingiz|kimsan|kimsiz/)) return "Mening ismim " + who + ". Sizniki-chi?";
    if (has(/nima qil|nima ish|bandmisan|bandmisiz/)) return pick(["Hozir siz bilan suhbatlashyapman \ud83d\ude42", "Hech narsa, sizdan xabar kutayotgan edim."]);
    if (has(/soat|vaqt/)) return "Hozir soat " + ("0" + now.getHours()).slice(-2) + ":" + ("0" + now.getMinutes()).slice(-2) + ".";
    if (has(/sana|bugun nechi|qaysi kun/)) return "Bugun " + now.toLocaleDateString("uz-UZ") + ".";
    if (has(/rahmat|raxmat|tashakkur|minnatdor/)) return pick(["Arzimaydi!", "Marhamat, doim tayyorman."]);
    if (has(/xayr|hayr|ko'rishguncha|khayr|sog' bo'l|hayr/)) return pick(["Xayr! Ko'rishguncha.", "Xayr, omad tilayman!"]);
    if (has(/yaxshi|zo'r|ajoyib|a'lo|durust/)) return pick(["Xursandman! \ud83d\ude0a", "Juda yaxshi, shunday davom eting!"]);
    if (has(/yomon|charchadim|xafa|qiyin/)) return "Xafa bo'lmang, hammasi yaxshi bo'ladi. Dam oling.";
    if (has(/\bha\b|\bxa\b|ok\b|mayli|bo'pti/)) return "Yaxshi, tushundim.";
    if (has(/\byo'q\b|\byoq\b/)) return "Mayli, tushunarli.";
    if (has(/\?/)) return pick(["Qiziq savol! Batafsilroq yozing.", "Bu haqda o'ylab ko'rish kerak.", "Hmm, siz o'zingiz nima deb o'ylaysiz?"]);
    return pick(["Tushundim.", "Ha, davom eting.", "Qiziq ekan!", "Mayli, yaxshi.", "Yana nimalar bor?"]);
  }
  function openChat() {
    updateBadge();
    $("meName").textContent = me.ism + " " + me.familiya;
    $("meLogin").textContent = "@" + me.login;
    var c = contacts(); peer = c[0] || null;
    renderUsers(); renderMessages(); show("vChat"); $("msgInput").focus();
  }
  function renderUsers() {
    var ul = $("users"); ul.innerHTML = "";
    contacts().forEach(function (l) {
      var li = document.createElement("li");
      if (l === peer) li.className = "active";
      var a = document.createElement("div"); a.className = "ava"; a.textContent = l.charAt(0);
      var s = document.createElement("span"); s.textContent = l;
      li.appendChild(a); li.appendChild(s);
      li.onclick = function () { peer = l; renderUsers(); renderMessages(); $("msgInput").focus(); };
      ul.appendChild(li);
    });
  }
  function renderMessages() {
    var box = $("messages"); box.innerHTML = "";
    $("peerName").textContent = peer || "—";
    var list = load("cz3_msgs", []).filter(function (m) {
      return (m.from === me.login && m.to === peer) || (m.from === peer && m.to === me.login);
    });
    if (!list.length) {
      var e = document.createElement("div"); e.className = "empty";
      e.textContent = "Hali xabar yo'q. Salom yozib ko'ring."; box.appendChild(e);
    }
    list.forEach(function (m) {
      var d = document.createElement("div"); d.className = "bubble " + (m.from === me.login ? "me" : "other");
      d.appendChild(document.createTextNode(m.text));
      var t = document.createElement("small"); t.textContent = m.time; d.appendChild(t);
      box.appendChild(d);
    });
    if (typingTo && typingTo === peer) {
      var ty = document.createElement("div"); ty.className = "bubble other";
      ty.textContent = "yozmoqda..."; ty.style.opacity = ".6"; box.appendChild(ty);
    }
    box.scrollTop = box.scrollHeight;
  }
  function addMsg(from, to, text) {
    var list = load("cz3_msgs", []);
    var now = new Date(), hh = ("0" + now.getHours()).slice(-2), mm = ("0" + now.getMinutes()).slice(-2);
    list.push({ from: from, to: to, text: text, time: hh + ":" + mm });
    save("cz3_msgs", list);
  }
  function send() {
    var text = $("msgInput").value.trim();
    if (!text || !peer) return;
    var to = peer;
    addMsg(me.login, to, text); $("msgInput").value = ""; renderMessages();
    askReply(to, text);
  }

  /* ---- Claude AI bilan javob ---- */
  var aiOn = false, typingTo = null;
  function updateBadge() {
    var b = $("aiBadge");
    b.textContent = aiOn ? "● Claude AI yoqilgan" : "● Oddiy rejim";
  }
  function history(to) {
    return load("cz3_msgs", []).filter(function (m) {
      return (m.from === me.login && m.to === to) || (m.from === to && m.to === me.login);
    }).slice(-20).map(function (m) {
      return { role: m.from === me.login ? "user" : "assistant", content: m.text };
    });
  }
  function finishReply(to, text) {
    addMsg(to, me.login, text); typingTo = null;
    if (peer === to) renderMessages();
  }
  function askReply(to, text) {
    typingTo = to; renderMessages();
    var greet = /salom|assalom/i.test(text) && text.length < 30;
    if (!aiOn || greet) {
      setTimeout(function () { finishReply(to, getReply(text, to)); }, 700);
      return;
    }
    fetch("/api/chat", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ persona: to, messages: history(to) })
    }).then(function (r) {
      return r.json().then(function (d) {
        if (!r.ok || !d.reply) throw new Error(d.error || "xato");
        return d.reply;
      });
    }).then(function (t) { finishReply(to, t); })
      .catch(function () { finishReply(to, getReply(text, to)); });
  }
  if (location.protocol.indexOf("http") === 0) {
    fetch("/api/status").then(function (r) { return r.json(); })
      .then(function (d) { aiOn = !!d.ai; updateBadge(); }).catch(function () {});
  }
  function logout() {
    me = null; peer = null; save("cz3_session", "");
    $("lParol").value = ""; say("lMsg", ""); show("vLogin");
  }

  /* ---- Tugmalar ---- */
  $("goRegister").onclick = function () { say("rMsg", ""); show("vRegister"); };
  $("goLogin").onclick = function () { say("lMsg", ""); show("vLogin"); };
  $("doLogin").onclick = doLogin;
  $("doRegister").onclick = doRegister;
  $("doSend").onclick = send;
  $("doLogout").onclick = logout;
  [["lLogin", doLogin], ["lParol", doLogin], ["rParol2", doRegister], ["msgInput", send]].forEach(function (p) {
    $(p[0]).addEventListener("keydown", function (e) { if (e.key === "Enter") p[1](); });
  });

  /* ---- Boshlanish: oldin kirgan bo'lsa chatga ---- */
  var s = load("cz3_session", "");
  var u = s && users().filter(function (x) { return x.login === s; })[0];
  if (u) { me = u; openChat(); }
})();
